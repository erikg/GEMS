#include <stdlib.h>
#include "defs.h"
#include "ll.h"

#define BLOCKSIZE 65535
#define TABLESIZE 10000

typedef struct _ll {
	char *mem;
	char **table;
	int current, last;
	char *blockend;
}
ll;

void *ll_newlist (void)
{
	ll *x;
	x=(ll *)malloc(sizeof(ll));
	x->mem=(char *)malloc(sizeof(char)*BLOCKSIZE);
	x->table=(char **)malloc(sizeof(void *)*TABLESIZE);

	if(x->mem==NULL && x->table==NULL)
		printf("Malloc failed in new list\n");

	memset(x->mem,0,BLOCKSIZE);
	memset(x->table,0,TABLESIZE);

	x->current=x->last=0;
	x->blockend=x->mem+BLOCKSIZE;
	return x;
}

int ll_next (void *list)
{
	ll *x;
	x=(ll *)list;
	if(x!=NULL && (x->current < (x->last-1)))
	{
		x->current++;
		return TRUE;
	}
	return FALSE;
}

int ll_rewind (void *list)
{
	if(list==NULL)return FALSE;
	((ll *)list)->current=0;
	return TRUE;
}

int ll_addnode (void *list, char *line)
{
	ll *x;
	if(list==NULL || line==NULL)return FALSE;
	x=(ll *)list;
	if(x->mem==NULL || x->table==NULL){printf("addnode: Whoa, either mem or table is NULL!\n"); return FALSE;}
	if( (strlen(line)+x->table[x->last]+1) > x->blockend )
	{	/* we have overflowed the current block */
		char *old;
		char **old2;
		long blocksize = x->blockend - x->mem;
		long blockdiff;
		int i;

		old=x->mem;
/*		x->mem=NULL;
		x->mem=(char *)malloc(sizeof(char)*blocksize*2);
		memcpy(x->mem,old,blocksize*sizeof(char));
		printf("x:%x x->mem:%x old:%x\n",x,x->mem,old);
		free(old);*/
		x->mem=(char *)realloc(x->mem,blocksize*2);
		blockdiff=old-x->mem;
		memset(x->mem+blocksize,0,blocksize);
		x->blockend=x->mem+(2*blocksize);
/*		old2=x->table;
		x->table=(char **)malloc(sizeof(x->table)*2);
		memcpy(x->mem,old,sizeof(old));
		memset(x->mem+sizeof(old),0,sizeof(old));
		free(old2);*/
		x->table=(char **)realloc(x->table,sizeof(x->table)*2);
		for(i=0;i<x->last;i++)
			x->table[i]+=blockdiff;
	}
	if(x->last==0)
	{
		memcpy(x->mem,line,strlen(line));

		x->table[0] = x->mem;
		x->last++;
	} else {
		char *last;
		last=x->table[x->last-1];
		x->table[x->last]=last+strlen(last)+1;
		memcpy(x->table[x->last],line,strlen(line)+1);
		x->last++;
	}
	return TRUE;
}

int ll_deletenode (void *list)
{
	int x;
	ll *l;
	if(list==NULL)return FALSE;
	l=(ll *)list;
	for(x=l->current;x<=l->last;x++)
		l->table[x]=l->table[x+1];
	l->last--;
}

char *ll_showline (void *list)
{
	if(list==NULL)return NULL;
	return ((ll *)list)->table[((ll *)list)->current];
}

int ll_clearlist (void *list)
{
	ll *x;
	if(list==NULL)return FALSE;
	x=(ll *)list;
	free(x->mem);
	free(x->table);
	free(x);
	return TRUE;
}

int ll_empty (void *list)
{
	if( ((ll *)list)->last == 0) return TRUE;
	return FALSE;
}

int ll_end(void *list)
{
	if( ((ll *)list)->current == ((ll *)list)->last) return TRUE;
	return FALSE;
}
